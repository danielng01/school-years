
      //Set your global init settings here
      //This is the setting you are looking for!      
  $.mobile.defaultPageTransition = 'none';
  $.mobile.buttonMarkup.hoverDelay = 0;
function SubmitNote() {
	var title = document.getElementById("title");
	var content = document.getElementById("noteContent");
	var noteObject = { 'title' : title.value, 'content': content.value};
	localStorage.setItem(localStorage.length, JSON.stringify(noteObject));
}
var tpl = new Array();

function load_templates() {
    // Extend this array if you have more templates
    var templates = ['index2'];

    $.each( templates, function( i, e ) {
        $.ajax({
            url: 'tpl/' + e + '.tpl',
            success: function( data ) {
                tpl[ e ] = data;
            },
            async: false,
            dataType: 'html'
            });
    });
}

$('#page').on('pagecreate', function(event) {
    // Load the templates
    load_templates();
    for (i = 0; i < localStorage.length; i++) {
    	var data = JSON.parse(window.localStorage.getItem(i));
	    var renderedHtml = Mustache.to_html( tpl['index2'], data );
	    $('#notes').append(renderedHtml );
	   
    }
});

$("#delete-all-notes").bind('vclick', function(){
	localStorage.clear();
	alert("Deleted...");
	document.location = "index.html";
}); 