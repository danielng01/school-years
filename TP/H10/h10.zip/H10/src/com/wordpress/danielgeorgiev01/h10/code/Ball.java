package com.wordpress.danielgeorgiev01.h10.code;

public class Ball {
	private int id;

	public Ball(int value){
		id = value;
	}

	public void setId(int value){
		id = value;
	}

	public int getId(){
		return id;
	}
}
