package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import examprep.School;
import examprep.Student;

public class Tests {
	School school;
	Student student;
	@Before
	public void setUp(){
		 school = new School();
		 student = new Student();
	}
	
	@Test
	public void testAddStudent(){
		assertEquals(0,school.numberOfStudents());
		school.addStudent(student);
		assertEquals(1,school.numberOfStudents());
	}
	
	@Test
	public void testRemoveStudent(){
		assertEquals(0, school.numberOfStudents());
		school.addStudent(student);
		assertEquals(1,school.numberOfStudents());
		school.removeStudent(student);
		assertEquals(0, school.numberOfStudents());
	}
	@Test 
	public void testFindStudentByName(){
		String name="pesho";
		Student stud = new Student(name,"male",11);
		school.addStudent(stud);
		assertEquals(stud, school.findStudentByName(name));
		assertEquals(null, school.findStudentByName("gosho"));
	}
	@Test
	public void testSorted(){
		Student s1 = new Student("pesho", "male",5);
		Student s2 = new Student("ivan", "male",6);
		Student s3 = new Student("kolio", "male",7);
		Student s4 = new Student("iva", "female",3);
		Student s5 = new Student("ivana", "female",2);
		Student s6 = new Student("ivanaaa", "female",6);
		school.addStudent(s1);
		school.addStudent(s2);
		school.addStudent(s3);
		school.addStudent(s4);
		school.addStudent(s5);
		school.addStudent(s6);
		school.getSortedByGenderAndAge();
		assertEquals("male",school.getStudent(2).getGender());
		assertEquals("male",school.getStudent(1).getGender());
		assertEquals(5,school.getStudent(0).getAge());
		assertEquals(7,school.getStudent(2).getAge());
	}
}
