package examprep;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;



public class School {
	List<Student> st = new ArrayList<Student>();
	int stSize = 0;
	public void addStudent(Student s){
		st.add(s);
		stSize++;
	}
	public Student getStudent(int index){
		return st.get(index);
	}
	public void removeStudent(Student s){
		if(st.contains(s)){
			st.remove(s);
			stSize--;
		}
	}
	public int numberOfStudents(){
		return stSize;
	}
	public Student findStudentByName(String name){
		for(Student student: st){
			if(student.getName()==name){
				return student;
			}
		}
		return null;
	}
	public void getSortedByGenderAndAge(){
		List<Student> maleList = new ArrayList<Student>();
		List<Student> femaleList = new ArrayList<Student>();
		for(Student s : st){
			if(s.getGender()=="male"){
				maleList.add(s);
			}else{
				femaleList.add(s);
			}
			
		}
		Comparator comparator = new Comparator<Student>(){
			@Override
			public int compare(Student s1, Student s2){
				return s1.getAge() - s2.getAge();
			}
		};
		Collections.sort(femaleList,comparator);
		Collections.sort(maleList,comparator);
		st.clear();
		st.addAll(maleList);
		st.addAll(femaleList);
		
	}
}
