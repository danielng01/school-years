package com.wordpress.danielgeorgiev01.c14.code;

public class Site {
	String url;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	Page pages[];
	Site(String url)
	{
		this.url=url;
	}
}
