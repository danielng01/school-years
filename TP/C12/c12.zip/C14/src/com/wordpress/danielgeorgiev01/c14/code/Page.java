package com.wordpress.danielgeorgiev01.c14.code;

public class Page {
	String content;
	String url;
	String links[];
	Page(String content, String url){
		
	}
}
