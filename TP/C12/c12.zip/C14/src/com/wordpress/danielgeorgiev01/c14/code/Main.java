package com.wordpress.danielgeorgiev01.c14.code;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Main {

	public static void main(String[] args) throws IOException {
       /* String HTMLPage="";
        try {
            URL my_url = new URL("http://google.bg");
            BufferedReader br = new BufferedReader(new InputStreamReader(my_url.openStream()));
            String strTemp = "";

            while(null != (strTemp = br.readLine())){
            System.out.println(strTemp);
            HTMLPage+=strTemp;
        }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        Pattern linkPattern = Pattern.compile("(<a[^>]+>.+?</a>)",  Pattern.CASE_INSENSITIVE|Pattern.DOTALL);
        Matcher pageMatcher = linkPattern.matcher(HTMLPage);
        ArrayList<String> links = new ArrayList<String>();
        while(pageMatcher.find()){
            links.add(pageMatcher.group());
        }
        for (String item : links) {   
            System.out.println(item);
        }*/
		Site site = new Site("http://test-1430.apphb.com");
        Document doc = Jsoup.connect(site.url).get();
        String pageContent = doc.outerHtml();
        System.out.println(doc);
        Page page = new Page(pageContent,site.url);
        Element content = doc.getElementById("content");
        Elements links = doc.select("a[href]");
        int numLinks = links.size();
        site.pages = new Page[numLinks];
        int i=0;
        for (Element link : links) {
            String linkHref = link.attr("href");
          System.out.println(linkHref);
          site.pages[i]=linkHref;
          i++;
          
        }
	}

}
