package com.wordpress.danielgeorgiev01.c14.code;

public class Link {
	String value;
	public void download(){
		
	}
}
